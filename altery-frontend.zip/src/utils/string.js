export const BASE_URL =
  'https://7fblhqlwkb.execute-api.us-east-1.amazonaws.com/production/'
